"use client"

export default function GlowMenu() {
  return null
}
